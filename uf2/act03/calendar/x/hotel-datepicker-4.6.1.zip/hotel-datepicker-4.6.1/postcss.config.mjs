const config = {
    plugins: {
        "postcss-sort-media-queries": { sort: "mobile-first" },
        autoprefixer: {},
    },
};

export default config;
